# Radar Instagram DICOM - v4.0 (Historical + Individual Files)
import os
import requests
import pandas as pd
import json
import time
import re
from datetime import datetime

# Configurações
API_KEY = os.environ.get("API_SRAPER_KEY")

PERFIS = {
    "Reitoria": "ifbaiano",
    "Alagoinhas": "ifbaiano_alagoinhas",
    "Bonfim": "ifbainaobonfimoficial",
    "Catu": "ifbaianocampuscatu",
    "Guanambi": "ifbaianoguanambi",
    "Itaberaba": "ifbaiano.itaberaba",
    "Itapetinga": "ifbaiano_itapetinga",
    "Lapa": "ifbaiano_lapa",
    "Mangabeira": "ifbaiano.govmangabeira",
    "Santa_Inês": "ifbaiano.santaines",
    "Serrinha": "ifbaianoserrinha",
    "Teixeira": "ifbaianoteixeiradefreitas",
    "Uruçuca": "ifbaiano_urucuca",
    "Valença": "ifbaiano_valenca",
    "Xique_Xique": "ifbaiano.xiquexique"
}

def parse_serper_date(date_str):
    now = datetime.now()
    date_str = date_str.lower()
    try:
        if 'ago' in date_str:
            num_match = re.search(r'\d+', date_str)
            if num_match:
                n = int(num_match.group())
                if 'day' in date_str: return now - pd.Timedelta(days=n)
                elif 'hour' in date_str: return now - pd.Timedelta(hours=n)
                elif 'week' in date_str: return now - pd.Timedelta(weeks=n)
                elif 'month' in date_str: return now - pd.Timedelta(days=n*30)
        parsed = pd.to_datetime(date_str, errors='coerce')
        return parsed if not pd.isna(parsed) else now
    except:
        return now

def get_data_serper(username, year=None):
    if not API_KEY: return []
    url = "https://google.serper.dev/search"
    
    # Se ano for fornecido, buscamos especificamente naquele ano
    query = f"site:instagram.com/p/ \"@{username}\""
    if year:
        query += f" after:{year-1}-12-31 before:{year+1}-01-01"
    
    payload = json.dumps({"q": query, "num": 20})
    headers = {'X-API-KEY': API_KEY, 'Content-Type': 'application/json'}

    try:
        response = requests.post(url, headers=headers, data=payload, timeout=30)
        return response.json().get('organic', []) if response.status_code == 200 else []
    except:
        return []

def salvar_post(item, campus, user, existentes, force_overwrite=False):
    link = item.get('link', '')
    if '/p/' not in link: return False
    
    shortcode = link.split('/p/')[1].split('/')[0]
    if not force_overwrite and shortcode in existentes: return False

    dt_objeto = parse_serper_date(item.get('date', ''))
    ano = dt_objeto.year
    
    # Nome do arquivo conforme solicitado: Unidade_Ano.csv
    # Usamos o nome limpo do campus para o nome do arquivo
    campus_limpo = campus.replace(' ', '_').replace('-', '_')
    nome_arq = f"{campus_limpo}_{ano}.csv"
    
    registro = {
        "campus": campus,
        "unidade": user,
        "shortcode": shortcode,
        "data": dt_objeto.strftime('%d/%m/%Y %H:%M'),
        "legenda": f'"{item.get("snippet", "").replace(chr(10), " ").replace(chr(34), chr(39))}"',
        "link": link,
        "img_url": "https://placehold.co/400x300/27ae60/white?text=Instagram+Post",
        "dia_semana": dt_objeto.weekday(),
        "mes": dt_objeto.month
    }
    
    df = pd.DataFrame([registro])
    mode = 'w' if force_overwrite and not os.path.exists('flag_first_run_done') else 'a'
    header = not os.path.exists(nome_arq) or mode == 'w'
    
    df.to_csv(nome_arq, mode=mode, index=False, header=header, encoding='utf-8-sig', quoting=1)
    return True

def gerar_metricas():
    print("--- Gerando Métricas Consolidadas ---")
    arquivos = [f for f in os.listdir() if '.csv' in f and '_' in f]
    if not arquivos: return

    list_df = []
    for f in arquivos:
        try:
            df_temp = pd.read_csv(f)
            if not df_temp.empty: list_df.append(df_temp)
        except: continue
    
    if not list_df: return
    df = pd.concat(list_df, ignore_index=True)
    df['data_dt'] = pd.to_datetime(df['data'], format='%d/%m/%Y %H:%M', errors='coerce')
    df = df.dropna(subset=['data_dt'])
    
    stats = {
        "atualizado_em": datetime.now().strftime('%d/%m/%Y %H:%M'),
        "total_posts": len(df),
        "ranking": df['campus'].value_counts().to_dict(),
        "dias_produtivos": df['dia_semana'].value_counts().to_dict() if 'dia_semana' in df.columns else {},
        "inatividade": {}
    }
    
    DIAS_NOMES = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
    if not df.empty:
        id_dia = df['dia_semana'].value_counts().idxmax()
        stats["dia_mais_produtivo"] = DIAS_NOMES[int(id_dia)]
    
    for campus in PERFIS.keys():
        posts_campus = df[df['campus'] == campus]
        if not posts_campus.empty:
            ultima = posts_campus['data_dt'].max()
            stats['inatividade'][campus] = max(0, (datetime.now() - ultima).days)
        else:
            stats['inatividade'][campus] = 999

    with open('metricas.json', 'w', encoding='utf-8') as f:
        json.dump(stats, f, ensure_ascii=False, indent=4)

def executar():
    # Detecta se é a primeira execução para forçar a coleta de 2025 e 2026
    is_first_run = not os.path.exists('publicacoes_concluidas.flag')
    print(f"--- Radar Social DICOM v4.0 ({'MODO INICIAL' if is_first_run else 'MODO DIÁRIO'}) ---")
    
    existentes = set()
    if not is_first_run:
        # Carrega shortcodes existentes de todos os arquivos para evitar duplicatas
        for f in os.listdir():
            if f.endswith('.csv') and '_' in f:
                try: existentes.update(pd.read_csv(f)['shortcode'].astype(str).tolist())
                except: continue

    for campus, user in PERFIS.items():
        print(f"Processando @{user}...")
        
        if is_first_run:
            # Coleta Histórica: 2025 e 2026
            for ano in [2025, 2026]:
                print(f"  -> Buscando histórico de {ano}...")
                resultados = get_data_serper(user, year=ano)
                for item in resultados:
                    salvar_post(item, campus, user, existentes, force_overwrite=True)
                time.sleep(1)
        else:
            # Coleta Diária: Apenas o mais recente
            resultados = get_data_serper(user)
            novos = 0
            for item in resultados:
                if salvar_post(item, campus, user, existentes):
                    novos += 1
            print(f"  -> {novos} novos posts.")
        
        time.sleep(1)

    if is_first_run:
        with open('publicacoes_concluidas.flag', 'w') as f: f.write('done')
    
    gerar_metricas()

if __name__ == "__main__":
    executar()
